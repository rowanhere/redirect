pub const CU_LIMIT_CLAIM: u32 = 11_000;
pub const CU_LIMIT_RESET: u32 = 12_200;
pub const CU_LIMIT_MINE: u32 = 3200;
